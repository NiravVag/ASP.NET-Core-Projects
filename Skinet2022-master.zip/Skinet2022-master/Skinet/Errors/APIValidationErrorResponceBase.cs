﻿namespace Skinet.Errors
{
    public class APIValidationErrorResponceBase
    {
    }
}