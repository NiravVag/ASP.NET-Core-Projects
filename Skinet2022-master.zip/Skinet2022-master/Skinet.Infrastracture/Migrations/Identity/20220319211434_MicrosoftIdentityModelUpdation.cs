﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Skinet.Infrastracture.Migrations.Identity
{
    public partial class MicrosoftIdentityModelUpdation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
