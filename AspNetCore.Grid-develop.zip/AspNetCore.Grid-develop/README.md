Grid controls for ASP.NET Core projects

[![License](https://img.shields.io/badge/license-MIT-green.svg?style=plastic)](https://opensource.org/licenses/MIT)
[![Semantic](https://img.shields.io/badge/sem-ver-lightgrey.svg?style=plastic)](https://semver.org/)
[![NuGet](https://img.shields.io/nuget/v/NonFactors.Grid.Mvc6.svg?style=plastic)](https://www.nuget.org/packages/NonFactors.Grid.Mvc6/)
[![Docs](https://img.shields.io/github/release/NonFactors/AspNetCore.Grid.Web.svg?style=plastic&label=docs)](https://mvc6-grid.azurewebsites.net/)
[![Tip](https://img.shields.io/badge/tip-paypal-blue.svg?style=plastic&logo=paypal)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=CGQTQRG8AADYE&source=url)