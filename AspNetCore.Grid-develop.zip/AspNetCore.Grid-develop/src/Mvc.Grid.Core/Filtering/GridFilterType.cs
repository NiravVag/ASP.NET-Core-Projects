﻿namespace NonFactors.Mvc.Grid
{
    public enum GridFilterType
    {
        Single,
        Double,
        Multi
    }
}
