﻿namespace NonFactors.Mvc.Grid
{
    public enum GridFilterCase
    {
        Original,
        Upper,
        Lower
    }
}
