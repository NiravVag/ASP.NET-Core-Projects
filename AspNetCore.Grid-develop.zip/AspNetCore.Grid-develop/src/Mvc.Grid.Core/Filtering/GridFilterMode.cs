﻿namespace NonFactors.Mvc.Grid
{
    public enum GridFilterMode
    {
        Row,
        Excel,
        Header
    }
}
