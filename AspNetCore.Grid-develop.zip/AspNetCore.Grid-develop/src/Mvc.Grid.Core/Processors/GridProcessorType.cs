﻿namespace NonFactors.Mvc.Grid
{
    public enum GridProcessorType
    {
        Pre,
        Post
    }
}
