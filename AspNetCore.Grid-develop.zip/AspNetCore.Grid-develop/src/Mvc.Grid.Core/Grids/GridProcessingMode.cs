﻿namespace NonFactors.Mvc.Grid
{
    public enum GridProcessingMode
    {
        Automatic,
        Manual
    }
}
