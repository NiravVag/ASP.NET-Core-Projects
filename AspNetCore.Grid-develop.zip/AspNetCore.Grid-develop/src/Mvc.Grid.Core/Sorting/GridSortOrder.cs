﻿namespace NonFactors.Mvc.Grid
{
    public enum GridSortOrder
    {
        Asc,
        Desc
    }
}
