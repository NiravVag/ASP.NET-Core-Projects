# Contributing
- Before you start writing a pull request you should discuss it using GitHub issues.
- Bug reports should be provided with at least minimum repro, if it works on [documentation page](https://mvc6-grid.azurewebsites.net/) you must be doing something differently, please analyze the core of the problem first and provide as much details as you can.