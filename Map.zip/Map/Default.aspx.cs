using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

public partial class _Default : System.Web.UI.Page
{
    string url;
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void ButtonSearch_Click(object sender, EventArgs e)
    {
        try
        {
            string street = string.Empty;
            string city = string.Empty;
            string state = string.Empty;
            string zip = string.Empty;

            StringBuilder queryAddress = new StringBuilder();
            queryAddress.Append("http://maps.google.com/maps?q=");

            if (txtStreet.Text != string.Empty)
            {
                street = txtStreet.Text.Replace(' ', '+');
                queryAddress.Append(street + ',' + '+');
            }

            if (txtCity.Text != string.Empty)
            {
                city = txtCity.Text.Replace(' ', '+');
                queryAddress.Append(city + ',' + '+');
            }

            if (txtState.Text != string.Empty)
            {
                state = txtState.Text.Replace(' ', '+');
                queryAddress.Append(state + ',' + '+');
            }

            if (txtZipCode.Text != string.Empty)
            {
                zip = txtZipCode.Text.ToString();
                queryAddress.Append(zip);
            }
            url = queryAddress.ToString();
            Response.Redirect(url, false);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString(), "Unable to Retrieve Map");
        }
    }

    protected void ButtonLatLong_Click(object sender, EventArgs e)
    {
        if (txtLat.Text == string.Empty || txtLong.Text == string.Empty)
        {
            MessageBox.Show("Supply a latitude and longitude value", "Missing Data");
            return;
        }

        try
        {
            string lat = string.Empty;
            string lon = string.Empty;

            StringBuilder queryAddress = new StringBuilder();
            queryAddress.Append("http://maps.google.com/maps?q=");

            if (txtLat.Text != string.Empty)
            {
                lat = txtLat.Text;
                queryAddress.Append(lat + "%2C");
            }

            if (txtLong.Text != string.Empty)
            {
                lon = txtLong.Text;
                queryAddress.Append(lon);
            }
            url = queryAddress.ToString();
            Response.Redirect(url, false);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message.ToString(), "Error");
        }
    }
}
